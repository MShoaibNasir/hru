@extends('dashboard.layout.master')
@section('content')
<style>
    .download_btn {
        width: 100%;
        display: flex;
        justify-content: end;
    }
    
    .csv_button {
    text-align: justify;
}
</style>

<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    @include('dashboard.layout.navbar')
    <!-- Navbar End -->
    <div class="container-fluid pt-4 px-4 form_width">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Beneficiaries Without Account</h6>
                </div>
            </div>
        </div>
       
        
         <div class="bg-light text-center rounded p-4">
              <div class='row'>
             
              </div>
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0" id="myTable">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">S NO</th>
                            <th scope="col">REFERENCE NO</th>
                            <th scope="col">BENEFICIARY FULL NAME</th>
                            <th scope="col">BENEFICIARY FATHER'S/HUSBAND NAME</th>
                            <th scope="col">CNIC/ID NUMBER</th>
                            <th scope="col">MARITAL STATUS</th>
                            <th scope="col">DATE OF ISSUANCE OF CNIC</th>
                            <th scope="col">MOTHER MAIDEN NAME</th>
                            <th scope="col">CITY OF BIRTH</th>
                            <th scope="col">CNIC EXPIRY STATUS</th>
                            <th scope="col">CNIC EXPIRY DATE</th>
                            <th scope="col">DATE OF BIRTH</th>
                            <th scope="col">VILLAGE/SETTLEMENT NAME</th>
                            <th scope="col">DISTRICT</th>
                            <th scope="col">TEHSIL</th>
                            <th scope="col">UC</th>
                            <th scope="col">NEXT OF KIN NAME</th>
                            <th scope="col">NEXT OF KIN CNIC</th>
                            <th scope="col">RELATIONSHIP WITH NEXT OF KIN</th>
                            <th scope="col">CONTACT NO OF NEXT OF KIN</th>
                            <th scope="col">PREFERED BANK</th>
                        
                        </tr>
                    </thead>
                    <tbody>
                       
                         @foreach($form as $item)
                         @php
                         $beneficiary=json_decode($item->beneficiary_details);
                         $ref_no=$beneficiary->b_reference_number;
                         $marital_status=get_answer(656,$item->survey_id);
                         $date_of_insurence_of_cnic=get_answer(618,$item->survey_id);
                         $mother_maiden_name=get_answer(616,$item->survey_id);
                         $city_of_birth=get_answer(617,$item->survey_id);
                         $cnic_expiry_status=get_answer(350,$item->survey_id);
                         $date_of_birth=get_answer(351,$item->survey_id);
                         $preferred_bank=get_answer(352,$item->survey_id);
                         $expiry_date=get_answer(675,$item->survey_id);
                         $next_kin_name=get_answer(657,$item->survey_id);
                         $cnic_of_kin=get_answer(658,$item->survey_id);
                         $relation_cnic_of_kin=get_answer(672,$item->survey_id);
                         $conatact_of_next_kin=get_answer(671,$item->survey_id);
                         $village_name=get_answer(2000,$item->survey_id);
                         $district=get_answer(1003,$item->survey_id);
                         $tehsil=get_answer(1004,$item->survey_id);
                         $uc=get_answer(1005,$item->survey_id);
                        
                         
                        @endphp
                        @if(!in_array($ref_no,$ref_no_list))
                            <tr>
                                <td>{{$loop->index+1}}</td>
                                <td>{{$ref_no ?? 'not available'}}</td>
                                <td>{{$beneficiary->beneficiary_name ?? 'not available'}}</td>
                                <td>{{$beneficiary->father_name ?? 'not available'}}</td>
                                <td>{{$beneficiary->cnic ?? 'not available'}}</td>
                                <td>{{$marital_status->answer ?? 'not available'}}</td>
                                <td>{{$date_of_insurence_of_cnic->answer ?? 'not available'}}</td>
                                <td>{{$mother_maiden_name->answer ?? 'not available'}}</td>
                                <td>{{$city_of_birth->answer ?? 'not available'}}</td>
                                <td>{{$cnic_expiry_status->answer ?? 'not available'}}</td>
                                <td>{{$expiry_date->answer ?? 'not available'}}</td>
                                <td>{{$date_of_birth->answer ?? 'not available'}}</td>
                                <td>{{$village_name->answer ?? 'not available'}}</td>
                                <td>{{$district->answer ?? 'not available'}}</td>
                                <td>{{$tehsil->answer ?? 'not available'}}</td>
                                <td>{{$uc->answer ?? 'not available'}}</td>
                                <td>{{$next_kin_name->answer ?? 'not available'}}</td>
                                <td>{{$cnic_of_kin->answer ?? 'not available'}}</td>
                                <td>{{$relation_cnic_of_kin->answer ?? 'not available'}}</td>
                                <td>{{$conatact_of_next_kin->answer ?? 'not available'}}</td>
                                <td>{{$preferred_bank->answer ?? 'not available'}}</td>
                           
                            </tr>  
                        @endif
                        @endforeach    
                    </tbody>
                </table>
            </div>
        </div>
        
        
        
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>

    @if(session('error'))
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: "{{ session('error') }}",
                toast: true,         // This enables the toast mode
                position: 'top-end', // Position of the toast
                showConfirmButton: false, // Hides the confirm button
                timer: 3000          // Time to show the toast in milliseconds
            });
        </script>
    @endif
    @if(session('success'))
        <script>

            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "{{ session('success') }}"
            });
        </script>
    @endif
    @endsection