@extends('dashboard.layout.master')
@section('content')
<style>
    .download_btn {
        width: 100%;
        display: flex;
        justify-content: end;
    }
</style>

<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    @include('dashboard.layout.navbar')
    <!-- Navbar End -->
    <div class="container-fluid pt-4 px-4 form_width">
        <div class="row g-4">
            <div class="col-sm-12 col-xl-12">
                <div class="bg-light rounded h-100 p-4">
                    <h6 class="mb-4">Beneficiaries BioMetric Status</h6>
                   
                </div>
            </div>
        </div>
        
         <div class="bg-light text-center rounded p-4">
            <div class="table-responsive">
                <table class="table text-start align-middle table-bordered table-hover mb-0" id="myTable">
                    <thead>
                        <tr class="text-dark">
                            <th scope="col">S NO</th>
                            <th scope="col">REFERENCE NO</th>
                            <th scope="col">BENEFICIARY FULL NAME</th>
                            <th scope="col">BENEFICIARY FATHER'S/HUSBAND NAME</th>
                            <th scope="col">CNIC/ID NUMBER</th>
                            <th scope="col">MARITAL STATUS</th>
                            <th scope="col">ACCOUNT NUMBER</th>
                            <th scope="col">BANK NAME</th>
                            <th scope="col">BRANCH NAME</th>
                            <th scope="col">BANK ADDRESS</th>
                            <th scope="col">ACTION</th>
               

                        </tr>
                    </thead>
                    <tbody>
                     
                         @foreach($form as $item)
                         @php
                         $beneficiary=json_decode($item->beneficiary_details);
                         $marital_status=get_answer(656,$item->survey_id);
                   
                         $date_of_insurence_of_cnic=get_answer(618,$item->survey_id);
                         $mother_maiden_name=get_answer(616,$item->survey_id);
                         $city_of_birth=get_answer(617,$item->survey_id);
                         $cnic_expiry_status=get_answer(350,$item->survey_id);
                         $date_of_birth=get_answer(351,$item->survey_id);
                         $preferred_bank=get_answer(352,$item->survey_id);
                        @endphp
                         @if($item->answer=='No')
                            <tr>
                              <td>{{$loop->index+1}}</td>
                                <td>{{$item->ref_no ?? 'not available'}}</td>
                                <td>{{$beneficiary->beneficiary_name ?? 'not available'}}</td>
                                <td>{{$beneficiary->father_name ?? 'not available'}}</td>
                                <td>{{$beneficiary->cnic ?? 'not available'}}</td>
                                <td>{{$marital_status->answer ?? 'not available'}}</td>
                                <td>{{$item->account_number ?? 'not available'}}</td>
                                <td>{{$item->bank_name ?? 'not available'}}</td>
                                <td>{{$item->branch_name ?? 'not available'}}</td>
                                <td>{{$item->bank_address ?? 'not available'}}</td>
                                <td><a class='btn btn-success' href='{{route("verify.biometric.account",[$item->id])}}'>Verify Bio Metric</a></td>
                            </tr>
                         @endif    
                        @endforeach    
                    </tbody>
                </table>
            </div>
        </div>
        
        
        
    </div>
    <script src="https://code.jquery.com/jquery-3.7.1.js"></script>

    @if(session('error'))
        <script>
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: "{{ session('error') }}",
                toast: true,         // This enables the toast mode
                position: 'top-end', // Position of the toast
                showConfirmButton: false, // Hides the confirm button
                timer: 3000          // Time to show the toast in milliseconds
            });
        </script>
    @endif
    @if(session('success'))
        <script>

            const Toast = Swal.mixin({
                toast: true,
                position: "top-end",
                showConfirmButton: false,
                timer: 3000,
                timerProgressBar: true,
                didOpen: (toast) => {
                    toast.onmouseenter = Swal.stopTimer;
                    toast.onmouseleave = Swal.resumeTimer;
                }
            });
            Toast.fire({
                icon: "success",
                title: "{{ session('success') }}"
            });
        </script>
    @endif
    @endsection