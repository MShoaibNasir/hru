@php
$show_button_mne = monitoring_evaluation();
@endphp
@if(count($questions) > 0)
 @foreach($questions as $question)
     @if($question->type == "checkbox")
     <x-frontend.survey.typecheckbox :question="$question"/>
     @elseif($question->type == "map")
     <x-frontend.survey.typemap :question="$question"/>
     @elseif($question->type == "radio")
     <x-frontend.survey.typeradio :question="$question"/>
     @elseif($question->type == "image")
     <x-frontend.survey.typeimage :question="$question"/>
     @else
     <x-frontend.survey.typetext :question="$question"/>
     @endif
 @endforeach
@endif

@if($sectionid == 41)
@php 
$a = get_question_image($surveyformid, 290);
$location_a=get_question_location($surveyformid, 290);

$b = get_question_image($surveyformid, 291);
$location_b=get_question_location($surveyformid, 291);
@endphp
<div class="row">
@if($a)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $a }}" alt="{{ getquestionlabel(290) }}" class='myImg rotating-image'  />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(290) }}</p>
    {!! $location_a !!}
    
    @php
    $result= hideReject($surveyformid,290);
    $comment = is_monitoring_evaluation($surveyformid, 290);
    $reject_comment = is_question_reject($surveyformid, 290);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="290"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="290" action="comment" href="javascript:void(0)">Comment</a>
        @endif
        
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="290" action="revert" href="javascript:void(0)">Revert</a>
         @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="290" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($b)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $b }}" alt="{{ getquestionlabel(291) }}" class='myImg rotating-image' />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(291) }}</p>
    {!! $location_b !!}
    @php
    $result= hideReject($surveyformid,291);
    $comment = is_monitoring_evaluation($surveyformid, 291);
    $reject_comment = is_question_reject($surveyformid, 291);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="291"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="291" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="291" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="291" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
</div>
@endif



@if($sectionid == 86)
@php 
$a = get_question_image($surveyformid, 285);
$location_a=get_question_location($surveyformid, 285);
$b = get_question_image($surveyformid, 2305);
$location_b=get_question_location($surveyformid, 2305);
$c = get_question_image($surveyformid, 289);
$location_c=get_question_location($surveyformid, 289);
$d = get_question_image($surveyformid, 2306);
$location_d=get_question_location($surveyformid, 2306);
$e = get_question_image($surveyformid, 2076);
$location_e=get_question_location($surveyformid, 2076);
$f = get_question_image($surveyformid, 2499);
$location_f=get_question_location($surveyformid, 2499);
$g = get_question_image($surveyformid, 2536);
$location_g=get_question_location($surveyformid, 2536);
$h = get_question_image($surveyformid, 288);
$location_h=get_question_location($surveyformid, 288);
@endphp
<div class="row">
@if($a)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $a }}" alt="{{ getquestionlabel(285) }}" class='myImg rotating-image' />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(285) }} </p>
    {!! $location_a !!}
    @php
    $result= hideReject($surveyformid,285);
    $comment = is_monitoring_evaluation($surveyformid, 285);
    $reject_comment = is_question_reject($surveyformid, 285);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="285"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="285" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
       @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="285" action="revert" href="javascript:void(0)">Revert</a>
         @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="285" action="reject" href="javascript:void(0)">Reject</a>
        @endif
     @endif
     
     
     @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($b)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $b }}" alt="{{ getquestionlabel(2305) }}"  class='myImg rotating-image' />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(2305) }}</p>
    {!! $location_b !!}
    
     @php
    $result= hideReject($surveyformid,2305);
    $comment = is_monitoring_evaluation($surveyformid, 2305);
    $reject_comment = is_question_reject($surveyformid, 2305);
    @endphp
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="2305"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2305" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2305" action="revert" href="javascript:void(0)">Revert</a>
         @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2305" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($h)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $h }}" alt="{{ getquestionlabel(288) }}" class='myImg rotating-image' />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(288) }}</p>
     {!! $location_h !!}
    
     @php
    $result= hideReject($surveyformid,288);
    $comment = is_monitoring_evaluation($surveyformid, 288);
    $reject_comment = is_question_reject($surveyformid, 288);
    @endphp
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="288"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="288" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="288" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="288" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($c)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $c }}" alt="{{ getquestionlabel(289) }}" class='myImg rotating-image' />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(289) }}</p>
    {!! $location_c !!}
    
     @php
    $result= hideReject($surveyformid,289);
    $comment = is_monitoring_evaluation($surveyformid, 289);
    $reject_comment = is_question_reject($surveyformid, 289);
    @endphp
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="289"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="289" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="289" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="289" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($d)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $d }}" alt="{{ getquestionlabel(2306) }}"  class='myImg rotating-image' />
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(2306) }}</p>
     {!! $location_d !!}
    
    @php
    $result= hideReject($surveyformid,2306);
    $comment = is_monitoring_evaluation($surveyformid, 2306);
    $reject_comment = is_question_reject($surveyformid, 2306);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="2306"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2306" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2306" action="revert" href="javascript:void(0)">Revert</a>
       @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2306" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($e)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $e }}" alt="{{ getquestionlabel(2076) }}"  class='myImg rotating-image'  />
   <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(2076) }}</p>
    {!! $location_e !!}
    
    @php
    $result= hideReject($surveyformid,2076);
    $comment = is_monitoring_evaluation($surveyformid, 2076);
    $reject_comment = is_question_reject($surveyformid, 2076);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="2076"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2076" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2076" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2076" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($f)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $f }}" alt="{{ getquestionlabel(2499) }}" class='myImg rotating-image'/>
     <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(2499) }}</p>
     {!! $location_f !!}
     
    @php
    $result= hideReject($surveyformid,2499);
    $comment = is_monitoring_evaluation($surveyformid, 2499);
    $reject_comment = is_question_reject($surveyformid, 2499);
    @endphp
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="2499"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2499" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2499" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2499" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif

@if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif

@if($g)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $g }}" alt="{{ getquestionlabel(2536) }}"  class='myImg rotating-image' />
     <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(2536) }}</p>
     {!! $location_g !!}
     
    @php
    $result= hideReject($surveyformid,2536);
    $comment = is_monitoring_evaluation($surveyformid, 2536);
    $reject_comment = is_question_reject($surveyformid, 2536);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="2536"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2536" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2536" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2536" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif

  </div>
  </div></div>
@endif
</div>
@endif




@if($sectionid == 97)
@php 
$a = get_question_image($surveyformid, 293);
$location_a=get_question_location($surveyformid, 293);
$b = get_question_image($surveyformid, 294);
$location_b=get_question_location($surveyformid, 294);
@endphp
<div class="row">
@if($a)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $a }}" alt="{{ getquestionlabel(293) }}" class='myImg rotating-image' /> 
  <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(293) }}</p>
    {!! $location_a !!}
   
    
    @php
    $result= hideReject($surveyformid,293);
    $comment = is_monitoring_evaluation($surveyformid, 293);
    $reject_comment = is_question_reject($surveyformid, 293);
    @endphp
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="293"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="293" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="293" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="293" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
@if($b)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $b }}" alt="{{ getquestionlabel(294) }}" class='myImg rotating-image' />
   <button class="button_rotate">Rotate</button>
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(294) }}</p>
    {!! $location_b !!}
    
    @php
    $result= hideReject($surveyformid,294);
    $comment = is_monitoring_evaluation($surveyformid, 294);
    $reject_comment = is_question_reject($surveyformid, 294);
    @endphp
    
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="294"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="294" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="294" action="revert" href="javascript:void(0)">Revert</a>
        @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="294" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
</div>
@endif




@if($sectionid == 102)
@php 
$a = get_question_image($surveyformid, 2074);
$location_a=get_question_location($surveyformid, 2074);

@endphp
<div class="row">
@if($a)
<div class="col-md-6">
<div class="card pb-3 mb-3">
  <img src="{{ $a }}" alt="{{ getquestionlabel(2074) }}" class='myImg' />
  <div class="card-body">
    <p class="card-text">{{ getquestionlabel(2074) }}</p>
    {!! $location_a !!}
    
    @php
    $result= hideReject($surveyformid,2074);
    $comment = is_monitoring_evaluation($surveyformid, 2074);
    $reject_comment = is_question_reject($surveyformid, 2074);
    @endphp
    @if($show_button_mne==true)
        @if($comment)
        <a class="btn btn-sm btn-success comment_revert" style="height:30px;" comment_id="{{ $comment->id }}" ques_id="2074"  href="javascript:void(0)">Remove Comment</a>
        @else
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2074" action="comment" href="javascript:void(0)">Comment</a>
        @endif
    @else
        @if($result && $result!=="hide functionality")
        <a class="btn btn-sm btn-success rejection_revert" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2074" action="revert" href="javascript:void(0)">Revert</a>
         @elseif($result==false && $result!="hide functionality")
        <a class="btn btn-sm btn-danger surveyquestion_rejectforms_btn" style="height:30px;" survey_id="{{ $surveyformid }}" ques_id="2074" action="reject" href="javascript:void(0)">Reject</a>
        @endif
    @endif
    
    
    @if($comment)
    <div class="my-3 alert alert-danger alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $comment->created_role ?? '' }}: </strong> {{ $comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
    
    @if($reject_comment)
    <div class="my-3 alert alert-primary alert-dismissible fade show" role="alert">
    <strong>Comment By {{ $reject_comment->created_role ?? '' }}: </strong> {{ $reject_comment->comment ?? '' }}
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    @endif
  </div>
  </div></div>
@endif
</div>
@endif